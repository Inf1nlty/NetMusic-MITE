package moddedmite.rustedironcore.mixin.chunk;

import com.llamalad7.mixinextras.sugar.Local;
import moddedmite.rustedironcore.api.event.Handlers;
import moddedmite.rustedironcore.api.event.handler.BiomeDecorationHandler;
import moddedmite.rustedironcore.api.world.Dimension;
import net.minecraft.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Random;

@Mixin(ChunkProviderHell.class)
public abstract class ChunkProviderHellMixin implements IChunkProvider {
    @Shadow
    private World worldObj;

    @Shadow
    private Random hellRNG;

    @Inject(method = "provideChunk", at = @At(value = "INVOKE", target = "Lnet/minecraft/MapGenNetherBridge;generate(Lnet/minecraft/IChunkProvider;Lnet/minecraft/World;II[B)V"))
    private void provideChunk$onMapGen(int par1, int par2, CallbackInfoReturnable<Chunk> cir, @Local byte[] bytes) {
        Handlers.MapGen.onChunkProvideMapGen(Dimension.NETHER, this, this.worldObj, par1, par2, bytes);
    }

    @Inject(method = "provideChunk", at = @At(value = "INVOKE", target = "Lnet/minecraft/MapGenNetherBridge;generate(Lnet/minecraft/IChunkProvider;Lnet/minecraft/World;II[B)V", shift = At.Shift.AFTER))
    private void provideChunk$onStructureGenerate(int par1, int par2, CallbackInfoReturnable<Chunk> cir, @Local byte[] bytes) {
        Handlers.MapGen.onChunkProvideStructures(Dimension.NETHER, this, this.worldObj, par1, par2, bytes);
    }

    @Inject(method = "populate", at = @At(value = "INVOKE", target = "Lnet/minecraft/MapGenNetherBridge;generateStructuresInChunk(Lnet/minecraft/World;Ljava/util/Random;II)Z", shift = At.Shift.AFTER))
    private void populate$onStructureGenerate(IChunkProvider par1IChunkProvider, int par2, int par3, CallbackInfo ci) {
        Handlers.MapGen.onChunkPopulateStructures(Dimension.NETHER, this.worldObj, this.hellRNG, par2, par3);
    }

    @Inject(method = "recreateStructures", at = @At(value = "INVOKE", target = "Lnet/minecraft/MapGenNetherBridge;generate(Lnet/minecraft/IChunkProvider;Lnet/minecraft/World;II[B)V", shift = At.Shift.AFTER))
    private void recreateStructures$onStructureGenerate(int par1, int par2, CallbackInfo ci) {
        Handlers.MapGen.onRecreateStructures(Dimension.NETHER, this, this.worldObj, par1, par2);
    }

    @Inject(method = "populate", at = @At(value = "INVOKE", target = "Lnet/minecraft/WorldInfo;getEarliestMITEReleaseRunIn()I", ordinal = 0))
    private void onDecoration(IChunkProvider par1IChunkProvider, int par2, int par3, CallbackInfo ci) {
        int blockX = par2 * 16;
        int blockZ = par3 * 16;
        Handlers.BiomeDecoration.onDecorate(
                BiomeDecorationHandler.context(
                        this.worldObj, BiomeGenBase.hell, BiomeGenBase.hell.theBiomeDecorator,
                        this.hellRNG, blockX, blockZ
                ));
    }
}
